<?php require_once 'cabecalho.php' ?>  

 <table class=" bordered">
        <thead >
          <tr>
              <h1 class="center">Escolha seu nivel </h1>         
          </tr>
        </thead>

        <tbody >
          <tr >
            <td class="center">
            <a  class="btn btn-success center " href="facil.php">Facil</a>
            </td>
          </tr>

          <tr>
         <td class="center">
        	<a  class="btn btn-info center" href="principal.php">Intermediario</a>
        </td>

          <tr>          
            <td class="center">
            <a  class="btn btn-danger center" href="dificil.php">Dificil</a>
            </td>
          </tr>

        </tbody>
      </table>



</body>
</html>