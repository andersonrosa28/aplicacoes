	var tempoInicial = $("#tempo-digitacao").text();
	var campo = $(".campo");

$(function(){
	atualizaTamanhoFrase();
	inicializaContadores();
	inicializaCronometro();
	$("#botao-reinicia").click(reiniciaJogo);
	AlteraCorCampo();
	
});

function atualizaTamanhoFrase(){
	/*pegando o numero de palavras que tem na frase*/
	var frase = $(".frase").text();
	var tamanhoDaFrase = frase.split(" ").length;
	var numeroDePalavras = $("#numeroDePalavras");
	numeroDePalavras.text(tamanhoDaFrase);
}

function inicializaContadores(){
	
	campo.on("input", function(){

	/*pegando o valor do conteudo do campo textarea*/
	var conteudo = campo.val();

	/*pegando o tamanho da frase*/
	/*   /\S+/  é um expreção regular que busca por qualquer campo vazio */
	var tamanhoFrase = conteudo.split(/\S+/).length -1;

	/*pegando o tamanho dos caracteres*/
	var tamanhoCaracteres  = conteudo.length;

	/*jogando o valor do tamanho da frase dentro do contador*/
	var contadordePalavras = $("#contador-palavras");
	contadordePalavras.text(tamanhoFrase);

	/*jogando o valor do tamanho dos caracteres dentro do contador*/
	var contadordeCaracteres = $("#contador-caracteres");
	contadordeCaracteres.text(tamanhoCaracteres);

	});
}

function inicializaCronometro(){

		var tempoRestante = $("#tempo-digitacao").text();
		/*a function one faz com que eu chame o metodo apenas uma vez*/
		campo.one("focus",function(){
		  $("#botao-reinicia").attr("disabled",true);		
		  var cronometroID = setInterval(function() {
			 //cada vez que eu der o foco no campo ele desminui 1 do valor
	        tempoRestante--;
	       
	        /*atualizando o tempo*/
	         $("#tempo-digitacao").text(tempoRestante);
	         //se o tempo for menor que 1, ele deixa o campo desabilidado e zera o a funciton
	         //set interval
	        if (tempoRestante < 1) {       
	         clearInterval(cronometroID); 	
	           	finalizaJogo();
	 			placar();
	           	}
	   	 }, 1000);
			/*valor que vai ser desminuido*/
	});
}

function reiniciaJogo(){
    
	campo.attr("disabled", false);
	campo.val("");
	$("#contador-palavras").text("0");
	$("#contador-caracteres").text("0");
	$("#tempo-digitacao").text(tempoInicial);
	 inicializaCronometro();
	campo.toggleClass("campo-desativado");
	campo.removeClass("borda-verde");
	campo.removeClass("borda-vermelha");
		
}	

function finalizaJogo(){
	 campo.attr("disabled", true);
	 campo.toggleClass("campo-desativado");
	 $("#botao-reinicia").attr("disabled",false);
}


function AlteraCorCampo(){
	//pegando a frase 
	var frase = $(".frase").text();;
	campo.on("input", function(){
		//pegando o que eu digitei
		var digitado = campo.val();
		//pegando um pedaço da frase, qual pedaço?
		//do inicio "0" até o que foi digitado
		var comparado = frase.substr(0,digitado.length);

		if(digitado == comparado){
			campo.addClass("borda-verde");
			campo.removeClass("borda-vermelha");
		}else{
			campo.addClass("borda-vermelha");
			campo.removeClass("borda-verde");
		}

	});
}

