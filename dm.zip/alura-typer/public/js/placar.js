function placar(){
	var corpoTabela= $("#corpo-tabela");
	var usuario = "Player";
	var numPalavra = $("#contador-palavras").text();
	var linha = novalinha(usuario,numPalavra);

//aqui to falando, jquery procura na minha linha quem tem a class
//botao-remover e no click executa a função botaoremove()
	linha.find(".botao-remover").click(botaoRemove);
//aqui estou falando para o jquery inserir(append) minha linha, no corpo da tabela
     corpoTabela.prepend(linha);
}

function botaoRemove(event){	
		event.preventDefault();
		$(this).parent().parent().remove();	
}

 function novalinha(usuario,palavra){

 	//criando um objeto linha 
	var linha = $("<tr>");
	var colunadoUsuario = $("<td>").text(usuario);
	var colunadoPalavras = $("<td>").text(palavra);
	var colunadoRemover = $("<td>");

	var link= $("<a>").addClass("botao-remover").attr("href","#");
	var icone = $("<i>").addClass("small").addClass("material-icons").text("delete");

//criando a estrutura da linha da nossa tabela
	link.append(icone);

	colunadoRemover.append(link)

	linha.append(colunadoUsuario);
	linha.append(colunadoPalavras);
	linha.append(colunadoRemover);

	return linha;
 }
