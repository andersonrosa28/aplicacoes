<?php require_once 'cabecalho.php' ?>  
    <p class="frase center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed rutrum mauris ut ex pulvinar, in mattis lectus pretium. Cras suscipit placerat maximus. Vestibulum non tincidunt lacus, sed ornare eros. </p>

    <ul class="informacoes center">
      <li>
         <i class="small material-icons icones">description</i>
        <span id="numeroDePalavras">10</span> palavras
      </li>

      <li>
         <i class="small material-icons icones">query_builder</i>
        <span id="tempo-digitacao">15</span> segundos
      </li>
    </ul>

    <textarea class="campo" rowls="8" col="5" placeholder="Digite o texto aqui para começar a jogar"></textarea>


     <button class="btn-floating btn-large waves-effect waves-light red"  id="botao-reinicia"><i  class="material-icons">restore</i></button>

      <ul class="center">
        <li><span id="contador-caracteres">0</span> caracteres</li>
        <li><span id="contador-palavras">0</span> palavras</li>

      
    </ul>
</div>
    <section>
      <h3 class="center" id="placar">Placar</h3>
      <div class="container">
      <table class="centered bordered">
    
        
          <hr> 
        <thead>
          <tr>
              <th>Nome</th>
              <th>Nº de palavras</th>
              <th>Remover</th>
          </tr>
        </thead>
        <tbody id="corpo-tabela">          
        </tbody>

      </table>
    </section>
   
  
</div> 
  
   <script src="js/jquery.js"></script>
   <script src="js/main.js"></script>
   <script src="js/placar.js"></script>
</body>
</html>
