<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>DM</title>
    <link rel="stylesheet" href="css/libs/materialize.min.css">
    <link rel="stylesheet" href="css/libs/google-fonts.css">
    <link href="https://fonts.googleapis.com/css?family=Bungee+Shade|Fredericka+the+Great" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Fredericka+the+Great" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet"> 
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body> 
    
    <div class="container">
  
   	<a href="#" class="media">média preço</a>
   <hr>
   	 <div  >
	<span >300</span>
		<input class="ranger" type="range" min="10" max="50" step="10" />
		<span class="ranger">max </span>
	</div>

	</div>	