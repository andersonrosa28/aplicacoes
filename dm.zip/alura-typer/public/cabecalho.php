<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>DM</title>
    <link rel="stylesheet" href="css/libs/materialize.min.css">
    <link rel="stylesheet" href="css/libs/google-fonts.css">
    <link href="https://fonts.googleapis.com/css?family=Bungee+Shade|Fredericka+the+Great" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Fredericka+the+Great" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet"> 
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body> 
     <nav class="titulo">
       <h1 class="center">EREAP</h1>
         <p class="desenvolvedor"><span class="borda ">Desenvolvido por Anderson Rosa</span></p>    

    </nav>
</div>

   <div class="container">