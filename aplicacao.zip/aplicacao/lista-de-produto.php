<?php
require_once 'cabecalho.php';
require_once 'funcoes-produto.php';
require_once 'logica-usuario.php';

verificaUsuario();
?>
<h1>Todos os produtos cadastrados</h1>
<table class="table">
    <?php
    $funcaoprodutos = listaprodutos($conexao);
//para cada produto que retornar da funçãoproduto salve em produtos
    foreach ($funcaoprodutos as $produtos) {
        ?>
        <img src

        <tr>
            <td ><span class="text-info">Nome</span> : <?= $produtos['nome'] ?></td> 
            <td ><span class="text-success">Preço</span>: <?= $produtos['preco']; ?></td>
            <td ><span class="text-info">Descrição</span>: <?= $produtos['descricao']; ?></td>
            <td>
                <span class="text-info">Categoria</span>: <?= $produtos['categoria_nome']; ?>
            </td>


            <!-- link para remover, passando o id do produto -->
            <td>
                <form action="remove-produto.php" method="post">
                    <input type="hidden" name="id" value="<?= $produtos['id'] ?>" />
                    <button class="btn btn-danger">remover</button>
                </form>
            </td>

            <td><a class="btn btn-primary" href="produto-altera-formulario.php?id=<?= $produtos['id'] ?>">Alterar</a></td>



                        <!--<span class="glyphicon glyphicon-remove-circle"></span>-->
        </tr>

        <?php
    }
    ?>
</table>   



<?php include 'rodape.php'; ?>
