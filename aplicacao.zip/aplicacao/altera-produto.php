<!-- toda variavel começa com $ -->
<?php
require_once 'cabecalho.php';
require_once 'conexao.php';
require_once 'funcoes-produto.php';
?>

<?php
// pegando os valores nome e preço
$id = $_POST["id"];
$nome = $_POST["nome"];
$preco = $_POST["preco"];
$descricao = $_POST["descricao"];
$categoria_id = $_POST['categoria_id'];

//se existe o valor/variavel usado na função post ele executa e retorna o valor
if(array_key_exists('usado', $_POST)) {
    $usado = "true";
} else {
    $usado = "false";
}
//criando conexão com o banco
//SE A CONEXÃO ESTIVER ABERTA E TODOS OS DADOS FOREM PASSADOS CORRETAMENTE ELE INSERE NO BANCO E MOSTRA A MENSAGEM DE SUCESSO





if (alteraProduto($conexao,$id, $nome, $preco, $descricao, $categoria_id, $usado)) {
    ?>

    <span class="alert alert-success" role="alert">Produto <?= $nome; ?> Alterado com sucesso!
        O seu preço é <?= $preco; ?> </span>
    <?php
} else {
    $msg = mysqli_error($conexao);
    ?>
    <!-- SE NÃO FOR PASSADO OS DADOS CORRETOS ELE MOSTRA A MENSAGEM DE ERRO-->
    <span class="alert alert-danger" role="alert">Ocorreu um erro o Produto <?= $nome; ?> não foi alterado!<?= $msg; ?></span>

    <?php
    //NÃO PE NECESSARIA FECHAR A CONEXÃO, POR PADRAO O PHP FECHA AUTOMATICAMENTE A CONEXÃO
    mysqli_close($conexao);
}
?>




<br><a href="index.php" class="btn btn-success espaco">Inicio</a>
<a href="formulario.php" class="btn btn-primary espaco">Cadastrar</a>


<?php
include'rodape.php';


