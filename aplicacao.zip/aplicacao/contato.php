<?php 
session_start();
$nome = $_POST["nome"];
$email = $_POST["email"];
$mensagem= $_POST["mensagem"];

require_once ("PHPMailerAutoload.php");

// crie um novo email:
$mail = new PHPMailer();

// dados do seu servidor.
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "anderson.rosa28@gmail.com";
$mail->Password = "44435754";


//quem envia e quem recebe

$mail->setFrom("anderson.rosa28@gmail.com", "Alura Curso PHP e MySQL");
$mail->addAddress("anderson.rosa28@gmail.com");

// título e o corpo da mensagem:
$mail->Subject = "Email de contato da loja";
$mail->msgHTML("<html>
<head>

</head>
<body>
	<h3>Mensagem enviada de : {$nome} <h3>

		<h3>Email: {$email}<h3>

			<h3>Mensagem do Usuario<h3>
		<p>{$mensagem}<p>
</body>
</html>");
$mail->AltBody = "de: {$nome}\nemail:{$email}\nmensagem: {$mensagem}";


//mensagem de sucesso ou erro
if($mail->send()) {
    $_SESSION["success"] = "Mensagem enviada com sucesso";
    header("Location: index.php");
} else {
    $_SESSION["danger"] = "Erro ao enviar mensagem " . $mail->ErrorInfo;
    header("Location: formulario-contato.php");
}
die();
?>