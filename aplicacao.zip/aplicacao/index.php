<!DOCTYPE html>
<!-- toda variavel começa com $ -->
<?php
require_once 'cabecalho.php';
require_once'logica-usuario.php';

?>


<?php if (usuarioEstaLogado()) { ?>

    <h3>Bem vindo</h3>
    

    <a class="btn btn-info btn-lg" href="formulario.php">Quero adicionar um produto</a>

<?php } else { ?>

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
  LOGIN/CADASTRO
</button>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Login</h4>
      </div>
      <div class="modal-body">
          
                  <form action="login.php" method="post">
                      <table class="table">
                            <tr>
                                <td><label for="email">Email</label></td>
                                <td><input class="form-control" type="email" name="email" id="email" ></td>
                            </tr>
                            <tr>
                                <td><label for="senha">Senha</label></td>
                                <td><input class="form-control" type="password" name="senha" id="senha" ></td>
                            </tr>
                            <tr>
                                
                            </tr>

                     </table>
                <td><button class="btn btn-success center" >Entrar</button></td>
                <td><a href="FormUsuario.php" class="btn btn-primary center">Cadastrar</a></td>
            </form>

        <?php } ?>

      </div>
      
    </div>
  </div>
</div>


    
<?php
include'rodape.php';
