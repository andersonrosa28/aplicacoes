<?php
require_once'conexao.php';

function listaprodutos($conexao) {
    $produtos = array();
    //chamei a o banco produtos de p com o "as", juntei (join) com o banco categorias que chamei de c 
    //onde (on) o id do categorias seja igual ao categoria_id dos produtos
    //vou trazer todos os campos de produtos
    //e do banco categoria vou trazer só o nome
    $resultado = mysqli_query($conexao, "select p.*,c.nome as categoria_nome from produtos as p join categorias as c on c.id=p.categoria_id");
    //enquanto tiver produto na lista ele ira mostrar
    while ($produto = mysqli_fetch_assoc($resultado)) {
        //pega cada produto do  array produtos e coloca em produto        
        array_push($produtos, $produto);
      
    }

    return $produtos;
}

function insereProduto($conexao, $nome, $preco, $descricao, $categoria_id, $usado) {
    $query = "insert into produtos (nome, preco, descricao, categoria_id, usado) values ('{$nome}',{$preco}, '{$descricao}', {$categoria_id}, {$usado})";
//inserindo no banco de dados o nome e o preço        
    return mysqli_query($conexao, $query);
}

function insereUsuario($conexao, $nome, $email, $senha) {
    $query = "insert into usuarios (nome, email, senha) values ('{$nome}','{$email}', {$senha})";
//inserindo no banco de dados o nome e o preço        
    return mysqli_query($conexao, $query);
}
function alteraProduto($conexao, $id, $nome, $preco, $descricao, $categoria_id, $usado) {
    $query = "update produtos set nome = '{$nome}', preco = {$preco}, descricao = '{$descricao}', 
        categoria_id= {$categoria_id}, usado = {$usado} where id = '{$id}'";
    return mysqli_query($conexao, $query);
}


function buscaProduto($conexao, $id) {
    $query = "select * from produtos where id = {$id}";
    $resultado = mysqli_query($conexao, $query);
    return mysqli_fetch_assoc($resultado);
}
function removeProduto($conexao, $id){
    //query para deletar produto pelo id
    $query = "delete from produtos where id = {$id}";
    //retorno a query e a conexao com o banco
    return mysqli_query($conexao, $query);
    
}