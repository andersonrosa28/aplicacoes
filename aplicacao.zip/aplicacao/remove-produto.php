<?php
require_once 'cabecalho.php';
require_once 'conexao.php';
require_once 'funcoes-produto.php';
require_once 'logica-usuario.php';

//pego o id da url 
$id = $_POST['id'];
//chamo a função remover passando o id e a conexao 
removeProduto($conexao, $id);
//redirecionamento para a pagina lista-produto.php
$_SESSION["sucess"] = "Produto removido com sucesso" ;
header("Location: lista-de-produto.php");
die();





include 'rodape.php';