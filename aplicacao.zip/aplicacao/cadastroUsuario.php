<!DOCTYPE html>
<?php
require_once 'cabecalho.php';
require_once 'conexao.php';
require_once 'funcoes-produto.php';
require_once 'logica-usuario.php';

?>

<?php
// pegando os valores nome e preço
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];


//criando conexão com o banco
//SE A CONEXÃO ESTIVER ABERTA E TODOS OS DADOS FOREM PASSADOS CORRETAMENTE ELE INSERE NO BANCO E MOSTRA A MENSAGEM DE SUCESSO





if (insereUsuario($conexao, $nome, $email, $senha)) {
    ?>

    <span class="alert alert-success" role="alert">Usuario <?= $nome; ?> adicionado com sucesso!
        </span>
    <?php
} else {
    $msg = mysqli_error($conexao);
    ?>
    <!-- SE NÃO FOR PASSADO OS DADOS CORRETOS ELE MOSTRA A MENSAGEM DE ERRO-->
    <span class="texte text-danger" role="alert">Ocorreu um erro o Usuario <?= $nome; ?> não foi adicionado!<?= $msg; ?></span>

    <?php
    //NÃO PE NECESSARIA FECHAR A CONEXÃO, POR PADRAO O PHP FECHA AUTOMATICAMENTE A CONEXÃO
    mysqli_close($conexao);
}
?>




<br><a href="index.php" class="btn btn-success espaco">Inicio</a>
<a href="formulario.php" class="btn btn-primary espaco">Cadastrar</a>


<?php
include'rodape.php';

