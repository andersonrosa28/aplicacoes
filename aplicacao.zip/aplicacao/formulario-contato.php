<?php 
require_once 'cabecalho.php';

?>

<form action="contato.php" method="post">
	<h1>Entre em contato conosco</h1>
	<h3>envie sua mensagem</h3>
	<table class="table">
		<tr>
			<td><label for="nome">Nome</label></td>
			<td><input class="form-control" type="text" name="nome" id="nome" placeholder="Digite seu nome"></td>
		</td>
		<tr>
			<td><label for="email">Email</label></td>
			<td><input class="form-control" type="text" name="email" id="email" placeholder="Digite seu email"></td>
		</td>
		<tr>
			<td><label for="mensagem">Mensagem</label></td>
			<td><input class="form-control" type="text" name="mensagem" id="mensagem" placeholder="Mensagem aqui"></td>
		</td>
		<tr>
		<td><button class="btn btn-primary">Enviar</button></td>
	</tr>


	</table>

</form>
<?php
require_once 'rodape.php'
?>