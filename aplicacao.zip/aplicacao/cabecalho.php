<?php
error_reporting(E_ALL ^ E_NOTICE);
require_once 'mensagem-alerta.php';
require_once'logica-usuario.php';
?>
<html>


    <head>
        <title>Cadastro de produto</title>
        <meta charset="utf-8">
        <link href="css/bootstrap.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i" rel="stylesheet">
        <script type="text/javascript" src="js/script.js"></script>
        <script type="text/javascript" src="js/jquery.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <style>
            .centraliza{
                float: right;
            }
        </style>
    </head>

    <div class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" href="index.php">Cadpro</a>
            </div>
            <div>
                <ul class="nav navbar-nav">
                    <li> <a href="formulario.php">Adiciona Produto</a></li>
                    <li> <a href="lista-de-produto.php">Produtos Cadastrados</a></li>
                    <li> <a href="#">Sobre</a></li>
                    <li> <a href="formulario-contato.php">Contato</a></li>  

                </ul>
            </div>  
 <?php if (usuarioEstaLogado()) { ?>
            <div class="dropdown nav navbar-nav navbar-right espacamento">
                  <button class="btn  black dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                      <?= usuarioLogado() ?>
                    <span class="caret"></span>
                  </button>
                  <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                    <!-- adicionando os botoes de login que veio no-->
                  <p  class="btn btn-primary form-control"><a class=" link" href="logout.php">Sign out</a></p>
               
   <?php }?>
                  </ul>
                </div>
           
        </div>
    </div>

    <body>


        <div class="container">

            <div class="principal">
                <?php mostraAlerta('sucess');
                mostraAlerta('danger');
                ?>