<?php

function listacategorias($conexao){
    //crio um array de categorias
    $categorias = array();
    //faço minha query
    $query="select * from categorias";
    //executo a query e a conexao
    $resultado = mysqli_query($conexao, $query);
    //faço o loop, que para cada elemento associado naquele array, ele pega e joga no array
    while($categoria = mysqli_fetch_assoc($resultado)){
        //coloque as linhas que vier para categoria, no array categorias
        array_push($categorias, $categoria);
    }
    
    return $categorias;
}

