<?php 

$conexao = mysqli_connect('localhost', 'root', '', 'loja'); 
        //abrindo a conexao/executando a conexao


