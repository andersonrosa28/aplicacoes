<!DOCTYPE html>
<!-- toda variavel começa com $ -->
<?php
require_once'cabecalho.php';
require_once'conexao.php';
require_once'categorias.php';
require_once 'logica-usuario.php';

verificaUsuario();
$categorias = listacategorias($conexao);
?>

<form action="adiciona-produto.php" method="post">
    <h1>Formulario de Cadastro</h1>
    <table class="table">
        <tr>
            <td><label  for="nome">Nome</label></td>
            <td> <input class="form-control" type="text" name="nome" id="nome" placeholder="digite seu nome"></td>
        </tr>

        <tr>
            <td> <label  for="preco">Preço</label></td>
            <td> <input class="form-control" type="number" name="preco" id="preco" placeholder="digite o preço"></td>
        </tr>
        <tr>
            <td> <label  for="descricao">Descrição</label></td>
            <td> <textarea class="form-control" name="descricao" id="descricao" placeholder="digite uma descrição"></textarea></td>
        </tr>

        <tr>
            <td><label>Categorias</label></td>
            <td>
                <select name="categoria_id" class="form-control">
                    <?php //chame o array categorias de categoria 
                    foreach ($categorias as $categoria) {
                        ?> 
                        <option value="<?= $categoria['id'] ?>">
                        <?= $categoria['nome'] ?>
                        </option>

<?php } ?>

                </select>                
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type="checkbox" name="usado" value="false">Produto usado </td>
        </tr>

        <tr>
            <td><input type="submit" class="btn btn-success espaco" value="Cadastrar"></td>
        </tr>
    </table>
</form>


<?php
include 'rodape.php';
