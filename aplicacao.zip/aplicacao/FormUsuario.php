<?php 
require_once 'cabecalho.php';

?>

<form action="cadastroUsuario.php" method="post">
	<h1>Cadastre seu novo usuario</h1>
	<h3></h3>
	<table class="table">
		<tr>
			<td><label for="nome">Nome</label></td>
			<td><input class="form-control" type="text" name="nome" id="nome" placeholder="Digite seu nome"></td>
		</td>
		<tr>
			<td><label for="email">Email</label></td>
			<td><input class="form-control" type="text" name="email" id="email" placeholder="Digite seu email"></td>
		</tr>
		<tr>
			<td><label for="senha">Senha</label></td>
			<td><input class="form-control" type="password" name="senha" id="password" placeholder="Digite sua senha"></td>
		</tr>
		
		<tr>
		<td><button class="btn btn-primary">Enviar</button></td>
	</tr>


	</table>

</form>
<?php
require_once 'rodape.php'
?>