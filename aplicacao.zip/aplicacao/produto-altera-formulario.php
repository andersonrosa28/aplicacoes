<?php
require_once 'cabecalho.php';
require_once 'conexao.php';
require_once 'categorias.php';
require_once 'funcoes-produto.php';

$id = $_GET['id'];
$produto = buscaproduto($conexao, $id);

$categorias = listacategorias($conexao);

$usado = $produto['usado'] ? "checked='checked'" : "";
?>

<form action="altera-produto.php" method="post">
    <h1>Altera Produto</h1>
    <input type="hidden" name="id" value="<?=$produto['id']?>" />
    <table class="table">
        <tr>
            <td><label  for="nome">Nome</label></td>
            <td> <input class="form-control" type="text" name="nome" id="nome" placeholder="digite seu nome" value="<?= $produto['nome']?>"></td>
        </tr>

        <tr>
            <td> <label  for="preco">Preço</label></td>
            <td> <input class="form-control" type="number" name="preco" id="preco" placeholder="digite o preço" value="<?= $produto['preco']?>"></td>
        </tr>
        <tr>
            <td> <label  for="descricao">Descrição</label></td>
            <td> <textarea class="form-control" name="descricao" id="descricao" placeholder="digite uma descrição">
                <?= $produto['descricao'] ?>
                </textarea></td>
        </tr>

        <tr>
            <td><label>Categorias</label></td>
            <td>
                <select name="categoria_id" class="form-control">
                    <?php //chame o array categorias de categoria 
                    foreach ($categorias as $categoria) {
                        $essaEhACategoria = $produto['categoria_id'] == $categoria['id'];
                        $selecao = $essaEhACategoria ? "selected='selected'" : "";
                        ?> 
                        <option value="<?= $categoria['id'] ?>" <?=$selecao?>>
                        <?= $categoria['nome'] ?>
                        </option>

<?php } ?>

                </select>                
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type="checkbox" name="usado" <?= $usado ?> value="false">Produto usado </td>
        </tr>

        <tr>
            <td><input type="submit" class="btn btn-success espaco" value="Alterar "></td>
        </tr>
    </table>
</form>


<?php
include 'rodape.php';
